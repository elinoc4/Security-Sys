<?php $__env->startSection('content'); ?>

<div class="content">
    <div form-family>
        <form action="/cars" method="POST" class="form-group">
            <?php echo csrf_field(); ?>
            <input type="text" name="plate_no" placeholder="Plate Number" class="form-control" />
            <input type="text" name="tally_no" placeholder="Tally Number" class="form-control"/>
            <select name="status" class="form-control">
                <option value="1">Check In</option>
                <option value="0">Check Out</option>
            </select>
            <input value="<?php echo e(now()); ?>" name="date" type="hidden"/>
            <input type="submit" name="CheckIn"/>
        </form>
        
    
    </div>
     <div class="col-lg-12 col-md-12">
                <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Cars</h4>
                  <p class="card-category">for <?php echo e(now('Y')); ?></p>
                </div>
                <div class="card-body table-responsive">
                  <table class="table table-hover">
                    <thead class="text-warning">
                      <th>ID</th>
                      <th>Plate Number</th>
                      <th>Tally Number</th>
                      <th>Date</th>
                    </thead>
                    <tbody>
                       <?php $__currentLoopData = $carst; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cars): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cars->id); ?></td>
                            <td><?php echo e($cars->plate_no); ?></td>
                            <td><?php echo e($cars->tally_no); ?></td>
                            <td><?php echo e($cars->date); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <?php echo e($carst->links()); ?>

              </div>
            </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kineypxv/ssystem.zaltservices.com/private/resources/views/cars.blade.php ENDPATH**/ ?>