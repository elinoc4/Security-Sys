<div>
    <table>
        <thead>
            <th>Name</th>
            <th>Type</th>
            <th>Idno</th>
            
        </thead>
        <tbody>
            <?php $__currentLoopData = $Staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
               <td> <?php echo e($staff->name); ?></td>
               <td> <?php echo e($staff->type); ?></td>              
               <td> <?php echo e($staff->idno); ?></td>
               
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\Users\Elijah\Desktop\new drive\Compressed\virtual box\root\blog\resources\views/show.blade.php ENDPATH**/ ?>