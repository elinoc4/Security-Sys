<div class="content">

    <form action="/result" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="search" placeholder="Search Staff"/>
        <input type="submit" name="submit" placeholder="Search"/>
        <h3>
            <?php if(session()->has('message')): ?>

                        <?php echo e(session()->get('message')); ?>



                    <?php endif; ?>
            </h3>

    </form>


</div>
<?php /**PATH /home/kineypxv/ssystem.zaltservices.com/private/resources/views/search.blade.php ENDPATH**/ ?>