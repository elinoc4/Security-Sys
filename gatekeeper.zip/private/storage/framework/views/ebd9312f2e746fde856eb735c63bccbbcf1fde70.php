<div>
    <form action="/result" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="search" placeholder="Search Staff"/>
        <input type="submit" name="submit" placeholder="Search"/>
    </form>
</div>
<h1>
<?php if(session()->has('message')): ?>
         
            <?php echo e(session()->get('message')); ?>

        
           
        <?php endif; ?>
</h1><?php /**PATH C:\Users\Elijah\Desktop\new drive\Compressed\virtual box\root\blog\resources\views/search.blade.php ENDPATH**/ ?>