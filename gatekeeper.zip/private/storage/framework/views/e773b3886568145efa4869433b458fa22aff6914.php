<?php $__env->startSection('content'); ?>
<div class="content">
    <div >
    <form action="/cars" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="plate_no" placeholder="Plate Number"/>
        <input type="text" name="tally_no" placeholder="Tally Number"/>
        <select name="status">
            <option value="1">Check In</option>
            <option value="0">Check Out</option>
        </select>
        <input type="submit" name="CheckIn"/>
    </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Elijah\Desktop\new drive\Compressed\virtual box\root\blog\private\resources\views/cars.blade.php ENDPATH**/ ?>