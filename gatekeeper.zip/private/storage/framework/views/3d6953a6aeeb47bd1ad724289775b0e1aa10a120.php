<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="form-family">
        <form action="/save" method="POST" class="form-group" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="file" placeholder="upload an excel file" class="" name="upload">
            
            <input type="submit" class="form-button">
            <?php if(session()->has('message')): ?>
                <h1>
                    <?php echo e(session()->get('message')); ?>

                </h1>
            <?php endif; ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kineypxv/ssystem.zaltservices.com/private/resources/views/index.blade.php ENDPATH**/ ?>