<?php $__env->startSection('content'); ?>
<div class="content">
    <form class="md-form" action="/save" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
  <div class="file-field">
    <div class="btn btn-secondary btn-sm float-left">
      <span>Choose file</span>
      <input type="file" name="upload">
    </div>
    <div class="file-path-wrapper">
      <input class="file-path validate btn btn-secondary" type="" placeholder="Upload your file">
    </div>
  </div>

</form>
   
    <div class="card-body">
        <div class="table-responsive">
             <table class="table">
                <thead class=" text-primary">
                    <th>Name</th>
                    <th>Type</th>
                    <th>Idno</th>
        
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        
                       <td><a href="/result/<?php echo e($staff->id); ?>" class=""> <?php echo e($staff->name); ?></a></td>
                       <td> <?php echo e($staff->type); ?></td>
                       <td> <?php echo e($staff->idno); ?></td>
                       
                       
                    </tr>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php echo e($Staff->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kineypxv/ssystem.zaltservices.com/private/resources/views/show.blade.php ENDPATH**/ ?>