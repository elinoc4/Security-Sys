<div>
    <form action="/carsearch" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" name="search" placeholder="Search Staff"/>
        <input type="submit" name="submit" placeholder="Search"/>
    </form>
</div>

<?php /**PATH C:\Users\Elijah\Desktop\new drive\Compressed\virtual box\root\blog\resources\views/search_car.blade.php ENDPATH**/ ?>