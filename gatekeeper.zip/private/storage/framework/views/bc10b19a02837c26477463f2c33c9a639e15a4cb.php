


<div>
   
    <a href="<?php echo e($staff_search['id']); ?>">
        
            <div> <?php echo e($staff_search['name']); ?></div>
            <div><?php echo e($staff_search['idno']); ?></div>
            <div><?php echo e($staff_search['type']); ?></div>
            <div><?php echo e($staff_search['dept']); ?></div>
            <div><?php echo e($status); ?></div>
    </a>
</div>
           
                
          
    

<?php /**PATH C:\Users\Elijah\Desktop\new drive\Compressed\virtual box\root\blog\resources\views/result.blade.php ENDPATH**/ ?>