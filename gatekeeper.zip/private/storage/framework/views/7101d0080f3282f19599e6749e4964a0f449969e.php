<div>
    <form action="/save" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" placeholder="upload an excel file" name="upload">
        <input type="submit">
        <?php if(session()->has('message')): ?>
            <h1>
                <?php echo e(session()->get('message')); ?>

            </h1>
        <?php endif; ?>
    </form>
</div><?php /**PATH C:\Users\Elijah\Desktop\new drive\Compressed\virtual box\root\blog\resources\views/index.blade.php ENDPATH**/ ?>