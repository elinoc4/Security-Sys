<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cars extends Model
{
    //
    protected $fillable = ['plate_no','tally_no','status','date'];
}
