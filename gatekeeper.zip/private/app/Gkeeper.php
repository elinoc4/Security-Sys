<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gkeeper extends Model
{
    //
    protected $fillable = ['name','idno','type','exp_date','dept'];
}
