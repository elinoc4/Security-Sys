<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Gkeeper;
use Faker\Generator as Faker;
use Illuminate\Support\Str;

$type = ['Staff','IT','Contract Staff'];
$factory->define(Gkeeper::class, function (Faker $faker) {
    return [
        'name'=> $faker->name,
        'idno'=> Str::random(5),
        'type'=>$type[rand(0,3)],
        'exp_date'=>$faker->dateTimeBetween('now', '+3 years'),
        'dept'=>$fake->departmentName,
    ];
});
